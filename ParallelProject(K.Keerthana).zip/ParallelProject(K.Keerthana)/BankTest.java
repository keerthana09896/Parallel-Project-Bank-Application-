package com.cg.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bank.exception.AccountException;
import com.cg.bank.exception.AmountException;
import com.cg.bank.exception.NameException;
import com.cg.bank.exception.PhoneNumberException;
import com.cg.bank.service.AccountServiceImpl;

public class BankTest {
	
	@Test
	public void ValidateNameTrue() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validateName("Gulshan"));
	}
	@Test 
	public void ValidateName() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validateName("Keerthana96"));
		assertEquals(false, as.validateName("Keerthana"));
		assertEquals(false, as.validateName("Keerthana@#"));
		assertEquals(false, as.validateName("090896"));
	}
	
	@Test
	public void ValidatePhoneNoTrue() throws PhoneNoException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validatePhoneNo("9494513087"));
	}
	
	@Test
	public void ValidatePhoneNo() throws PhoneNoException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validatePhoneNo("9494513087"));
		assertEquals(false, as.validatePhoneNo("65746"));
		assertEquals(false, as.validatePhoneNo("Keerthana"));
		assertEquals(false, as.validatePhoneNo("#$%^&"));
		assertEquals(false, as.validatePhoneNo("WelCome123"));
	}
	
	
	@Test
	public void ValidateAccountTrue() throws AccountException{
		AccountServiceImpl amt = new AccountServiceImpl();
		assertEquals(true, amt.validateAmount("65456"));
		
	}
	@Test 
	public void ValidateAccount() throws AmountException{
		AccountServiceImpl amt = new AccountServiceImpl();
		assertEquals(false, amt.validateAmount("5430"));
		assertEquals(false, amt.validateAmount("0"));
	}
	@Test
	public void ValidateAmountTrue() throws AmountException{
		AccountServiceImpl amt = new AccountServiceImpl();
		assertEquals(true, amt.validateAmount("456"));
	}
	
	@Test 
	public void ValidateAmount() throws AmountException{
		AccountServiceImpl amt = new AccountServiceImpl();
		assertEquals(false, amt.validateAmount("76"));
		assertEquals(false, amt.validateAmount("-813"));
	}
	

}
